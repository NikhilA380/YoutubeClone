package com.interview.youtubeclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoutubecloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
