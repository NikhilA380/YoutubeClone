package com.interview.youtubeclone.controller;

import com.interview.youtubeclone.entity.Video;
import com.interview.youtubeclone.repository.VideoRepository;
import com.interview.youtubeclone.service.VideoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class HomeController {

    private final VideoService videoService;

    public HomeController(VideoService videoService) {
        this.videoService = videoService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("videos", videoService.getAllVideos());
        return "home";
    }



}
