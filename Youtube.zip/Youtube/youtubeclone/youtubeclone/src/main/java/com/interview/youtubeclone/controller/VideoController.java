package com.interview.youtubeclone.controller;

import com.interview.youtubeclone.entity.Video;
import com.interview.youtubeclone.repository.VideoRepository;
import com.interview.youtubeclone.service.VideoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.support.ResourceRegion;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequestMapping("/videos")
public class VideoController {

    private final VideoRepository videoRepository;
    private final VideoService videoService;

    private static final String VIDEO_DIR = "uploads/videos/";
    private static final long CHUNK_SIZE = 1024 * 1024;

    public VideoController(VideoRepository videoRepository,
                           VideoService videoService) {
        this.videoRepository = videoRepository;
        this.videoService = videoService;
    }

    @GetMapping("/watch/{id}")
    public String watchVideo(
            @PathVariable Long id,
            Model model,
            HttpSession session
    ) {
        Video video = videoService.getVideoById(id);

        String sessionKey = "VIEWED_VIDEO_" + id;

        if (session.getAttribute(sessionKey) == null) {
            videoService.incrementViewCount(video);
            session.setAttribute(sessionKey, true);
        }

        model.addAttribute("video", video);
        return "watch";
    }


    @GetMapping("/upload")
    public String uploadPage() {
        return "upload";
    }

    @PostMapping("/upload")
    public String uploadVideo(@RequestParam String title,
                              @RequestParam String description,
                              @RequestParam MultipartFile file) throws Exception {
        videoService.uploadVideo(title, description, file);
        return "redirect:/";
    }

    @GetMapping("/stream/{filename}")
    public ResponseEntity<ResourceRegion> streamVideo(
            @PathVariable String filename,
            @RequestHeader HttpHeaders headers) throws IOException {

        Path path = Paths.get(VIDEO_DIR).resolve(filename);
        Resource video = new UrlResource(path.toUri());

        if (!video.exists()) {
            return ResponseEntity.notFound().build();
        }

        long contentLength = video.contentLength();

        HttpRange range = headers.getRange().isEmpty()
                ? HttpRange.createByteRange(0, CHUNK_SIZE)
                : headers.getRange().get(0);

        long start = range.getRangeStart(contentLength);
        long end = Math.min(start + CHUNK_SIZE - 1, contentLength - 1);

        ResourceRegion region =
                new ResourceRegion(video, start, end - start + 1);

        return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
                .contentType(MediaTypeFactory.getMediaType(video)
                        .orElse(MediaType.APPLICATION_OCTET_STREAM))
                .body(region);
    }
}
