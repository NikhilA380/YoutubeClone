package com.interview.youtubeclone.service;

import com.interview.youtubeclone.entity.Video;
import com.interview.youtubeclone.repository.VideoRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class VideoService {

    private final VideoRepository videoRepository;

    private final String VIDEO_DIR = "uploads/videos/";

    public VideoService(VideoRepository videoRepository) {
        this.videoRepository = videoRepository;
    }

    public List<Video> getAllVideos() {
        return videoRepository.findAll();
    }

    public void uploadVideo(String title, String description, MultipartFile file) throws Exception {

        // Ensure directory exists
        Files.createDirectories(Paths.get(VIDEO_DIR));

        // Generate safe unique filename
        String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path filePath = Paths.get(VIDEO_DIR + filename);

        // Save file to disk
        Files.write(filePath, file.getBytes());

        // Save metadata to DB
        Video video = new Video();
        video.setTitle(title);
        video.setDescription(description);
        video.setVideoPath(filename);
        video.setUploadedAt(LocalDateTime.now());
        video.setViews(0L);

        videoRepository.save(video);
    }

    public Video getVideoById(Long id){
        return videoRepository.findById(id).orElseThrow();
    }

    public void incrementViewCount(Video video){
        video.setViews(video.getViews()+1);
        videoRepository.save(video);
    }


}
